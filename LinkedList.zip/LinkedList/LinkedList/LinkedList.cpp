// LinkedList.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


int main()
{
	int choice = 1, d;
	List listA, listB;
	bool flag = 1; //1 for listA, 2 for listB

	while (choice != 0) {
		if (flag) {
			cout << "You are making changes to listA." << endl;
		}
		else {
			cout << "You are making changes to listB." << endl;
		}
		cout << "Enter 1 to switch list." << endl;
		cout << "Enter 2 to add a node to the head of the list." << endl;
		cout << "Enter 3 to add a node to the tail of the list." << endl;
		cout << "Enter 4 to delete a node from the list by data value." << endl;
		cout << "Enter 5 to delete a node from the head of the list." << endl;
		cout << "Enter 6 to delete a node from the tail of the list." << endl;
		cout << "Enter 7 to get number of nodes in the list." << endl;
		cout << "Enter 8 to print the list." << endl;
		cout << "Enter 9 to remove duplicates from the list." << endl;
		cout << "Enter 10 to partition the list." << endl;
		cout << "Enter 11 to select kth to last node." << endl;
		cout << "Enter 12 to add two numbers stored in reverse order in linked lists." << endl;
		cout << "Enter 13 to add two numbers stored in regular order in linked lists." << endl;
		cout << "Enter 0 to exit." << endl;

		cin >> choice;

		switch (choice) {
		case 1:
			flag = !flag;
			break;
		case 2:
			cout << "Enter the data to be added.";
			cin >> d;
			if (flag) {
				listA.AddNodeToHead(d);
			}
			else {
				listB.AddNodeToHead(d);
			}
			cout << "Node added." << endl;
			break;
		case 3:
			cout << "Enter the data to be added.";
			cin >> d;
			if (flag) {
				listA.AddNodeToTail(d);
			}
			else {
				listB.AddNodeToTail(d);
			}
			cout << "Node added." << endl;
			break;
		case 4:
			cout << "Enter the data to be deleted.";
			cin >> d;
			if (flag) {
				listA.DeleteNode(d);
			}
			else {
				listB.DeleteNode(d);
			}
			break;
		case 5:
			if (flag) {
				listA.DeleteHead();
			}
			else {
				listB.DeleteHead();
			}
			break;
		case 6:
			if (flag) {
				listA.DeleteTail();
			}
			else {
				listB.DeleteTail();
			}
			break;
		case 7:
			if (flag) {
				cout << "The list contains " << listA.GetNumNodes() << " nodes." << endl;
			}
			else {
				cout << "The list contains " << listB.GetNumNodes() << " nodes." << endl;
			}
			break;
		case 8:
			if (flag) {
				listA.PrintList();
			}
			else {
				listB.PrintList();
			}
			
			break;
		case 9:
			if (flag) {
				cout << listA.RemoveDuplicates() << " duplicate nodes deleted." << endl;
			}
			else {
				cout << listB.RemoveDuplicates() << " duplicate nodes deleted." << endl;
			}
			
			break;
		case 10:
			cout << "Enter the partition value." << endl;
			cin >> d;
			if (flag) {
				listA.Partition(d);
			}
			else {
				listB.Partition(d);
			}
			
		case 11:
			cout << "Enter k." << endl;
			cin >> d;
			if (flag) {
				cout << "With existing count: " << listA.kthToLast1(d)->GetData() << endl;
				cout << "Without existing count: " << listA.kthToLast2(d)->GetData() << endl;
				listA.kthToLastRecursive(d);
			}
			else {
				cout << "With existing count: " << listB.kthToLast1(d)->GetData() << endl;
				cout << "Without existing count: " << listB.kthToLast2(d)->GetData() << endl;
				listB.kthToLastRecursive(d);
			}
			
		case 12:
			listA.SumReverseLists(listB).PrintList();
			break;
		case 13:
			listA.SumForwardLists(listB).PrintList();
			break;
		case 0:
			break;
		}

	}
    return 0;
}


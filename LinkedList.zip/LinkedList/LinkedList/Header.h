#pragma once
#include "stdafx.h"



class Node {
private:
	int data;
	Node *next;
public:
	Node(int d);
	void SetData(int d);
	int GetData();
	void SetNext(Node *n);
	Node* GetNext();
	

};

class List {
private:
	int numNodes = 0;
	Node *first = nullptr;
	Node *last = nullptr;
public:
	int GetNumNodes();
	void AddNodeToHead(int d);
	void AddNodeToTail(int d);
	void AddNodeToHead(Node *n);
	void AddNodeToTail(Node *n);
	void DeleteNode(int d);
	void DeleteHead();
	void DeleteTail();
	void PrintList();
	int RemoveDuplicates();
	void Partition(int d);
	Node* kthToLast1(int k);
	Node* kthToLast2(int k);
	void kthToLastRecursive(int k);
	int kthToLastRecursive(Node *ptr, int k);
	List SumReverseLists(List b);
	List SumForwardLists(List b);
	void PadZeroes(int n);
	void Unpad(int n);
	int SumRecursive(Node *a, Node *b, int carry);
};
#include "stdafx.h"

Node::Node(int d) {
	data = d;
	next = nullptr;
}

void Node::SetData(int d) {
	data = d;
}

int Node::GetData() {
	return data;
}

void Node::SetNext(Node *n) {
	next = n;
}

Node* Node::GetNext() {
	return next;
}



int List::GetNumNodes() {
	return numNodes;
}

void List::AddNodeToHead(int d) {
	Node *ptr = new Node(d);
	ptr->SetNext(first);
	first = ptr;

	if (last == nullptr) {
		last = first;
	}
	numNodes++;
}

void List::AddNodeToHead(Node *n) {
	n->SetNext(first);
	first = n;

	if (last == nullptr) {
		last = first;
	}
	numNodes++;
}

void List::AddNodeToTail(int d) {
	Node *ptr = new Node(d);
	
	if (last == nullptr) {
		first = ptr;
		last = ptr;
		ptr->SetNext(nullptr);
	}
	else {
		last->SetNext(ptr);
		last = ptr;
		ptr->SetNext(nullptr);
	}
	numNodes++;
}

void List::AddNodeToTail(Node *n) {
	

	if (last == nullptr) {
		first = n;
		last = n;
		n->SetNext(nullptr);
	}
	else {
		last->SetNext(n);
		last = n;
		last->SetNext(nullptr);
	}
	numNodes++;
}

void List::DeleteNode(int d) {


	Node *ptr = first;
	Node *prev = ptr;
	
	while (ptr != nullptr) {
		if (ptr->GetData() == d) {
			if (ptr == first) {
				first = ptr->GetNext();
				delete ptr;
				numNodes--;
			}
			else if (ptr == last) {
				last = prev;
				last->SetNext(nullptr);
				delete ptr;
				numNodes--;
			}
			else {
				prev->SetNext(ptr->GetNext());
				delete ptr;
				numNodes--;
			}
			break;
		}
		prev = ptr;
		ptr = ptr->GetNext();
	}
}

void List::DeleteHead() {
	if (first == nullptr) {
		return;
	}
	if (first == last) {
		delete first;
		first = nullptr;
		last = nullptr;
		numNodes--;
		return;
	}

	Node *ptr = first;
	first = first->GetNext();
	delete ptr;
	numNodes--;
}

void List::DeleteTail() {
	if (last == nullptr) {
		return;
	}
	if (first == last) {
		delete first;
		first = nullptr;
		last = nullptr;
		numNodes--;
		return;
	}

	
	Node *prev = first;
	Node *ptr = first->GetNext();

	while (ptr != last) {
		prev = ptr;
		ptr = ptr->GetNext();
	}

	prev->SetNext(ptr->GetNext());
	last = prev;
	delete ptr;
	numNodes--;
}

void List::PrintList() {
	Node *ptr = first;

	while (ptr != nullptr) {
		cout << ptr->GetData() << endl;
		ptr = ptr->GetNext();
	}
}

int List::RemoveDuplicates() {
	int numDeleted = 0;
	Node *ptr1 = first;
	
	if (first != nullptr) {
		
		while (ptr1->GetNext() != nullptr) {
			Node *prev = ptr1;
			Node *ptr2 = ptr1->GetNext();

			while (ptr2 != nullptr) {
				if (ptr1->GetData() == ptr2->GetData()) {
					prev->SetNext(ptr2->GetNext());
					delete ptr2;
					ptr2 = prev->GetNext();
					numDeleted++;
				}
				else {
					prev = ptr2;
					ptr2 = ptr2->GetNext();
				}
			
			}
			ptr1 = ptr1->GetNext();
		}

	}

	return numDeleted;
}

void List::Partition(int d) {
	Node *ptr = first;

	List newList;

	while (ptr != nullptr) {
		this->first = ptr->GetNext();
		if (ptr->GetData() < d) {
			newList.AddNodeToHead(ptr);
		}
		else {
			newList.AddNodeToTail(ptr);
		}
		ptr = first;
	}

	this->first = newList.first;
}

Node* List::kthToLast1(int k) {
	//if number of nodes is known
	int kthToLast = numNodes - k;

	if (kthToLast <= 0) {
		return nullptr;
	}

	Node *ptr = first;

	for (int i = 1; i < kthToLast; i++) {
		ptr = ptr->GetNext();
		
	}

	return ptr;
}

Node* List::kthToLast2(int k) {
	//ifnumber of nodes is not known, we have to count nodes first

	int count = 0;
	Node *ptr = first;

	while (ptr != nullptr) {
		count++;
		ptr = ptr->GetNext();
	}

	int kthToLast = count - k;

	if (kthToLast <= 0) {
		return nullptr;
	}

	ptr = first;

	for (int i = 1; i < kthToLast; i++) {
		ptr = ptr->GetNext();
	}

	return ptr;
}

static int x;
void List::kthToLastRecursive(int k) {
	Node *ptr = first;

	kthToLastRecursive(first, k);
}

int List::kthToLastRecursive(Node *ptr, int k) {
	if (ptr == nullptr) {
		//this is one after the last node
		return -1;
	}
	int x = kthToLastRecursive(ptr->GetNext(), k) + 1;
	if (x == k) {
		cout << "kth to last node is: " << ptr->GetData() << endl;
	}
	return x;
}

List List::SumReverseLists(List b) {
	List sum;

	Node *aPtr = this->first;
	Node *bPtr = b.first;

	int carry = 0;
	while (aPtr != nullptr && bPtr != nullptr) {
		int s = aPtr->GetData() + bPtr->GetData() + carry;
		carry = s / 10;
		sum.AddNodeToTail(s % 10);

		aPtr = aPtr->GetNext();
		bPtr = bPtr->GetNext();
	}

	if (aPtr == nullptr && bPtr == nullptr) {
		if (carry > 0) {
			sum.AddNodeToTail(carry);
		}
		return sum;
	}

	if (aPtr == nullptr) {

		while (bPtr != nullptr) {
			int s = bPtr->GetData() + carry;
			carry = s / 10;
			sum.AddNodeToTail(s % 10);

			bPtr = bPtr->GetNext();
		}
		
	}
	else if (bPtr == nullptr) {

		while (aPtr != nullptr) {
			int s = aPtr->GetData() + carry;
			carry = s / 10;
			sum.AddNodeToTail(s % 10);

			aPtr = aPtr->GetNext();
		}

	}

	if (carry > 0) {
		sum.AddNodeToTail(carry);
	}


	return sum;


}

List List::SumForwardLists(List b) {
	int padCount = 0;
	bool flag = false;

	if (this->numNodes < b.numNodes && this->numNodes != 0) {
		padCount = b.numNodes - this->numNodes;
		this->PadZeroes(padCount);
		flag = true;
	}
	else if (b.numNodes < this->numNodes && b.numNodes != 0) {
		padCount = this->numNodes - b.numNodes;
		b.PadZeroes(padCount);
	}
	
	List sum;

	sum.SumRecursive(this->first, b.first, 0);

	if (flag == 1) {
		this->Unpad(padCount);
	}




	return sum;
}

void List::PadZeroes(int n) {
	for (int i = 0; i < n; i++) {
		this->AddNodeToHead(0);
	}
}

void List::Unpad(int n) {
	for (int i = 0; i < n; i++) {
		this->AddNodeToHead(0);
	}
}

int List::SumRecursive(Node *a, Node *b, int carry) {
	if (a->GetNext() == nullptr) {
		this->AddNodeToHead((a->GetData() + b->GetData() + carry) % 10);
		return (a->GetData() + b->GetData() + carry) / 10;
	}
	
	carry = SumRecursive(a->GetNext(), b->GetNext(), carry);
	this->AddNodeToHead((a->GetData() + b->GetData() + carry) % 10);
	return (a->GetData() + b->GetData() + carry) / 10;
}

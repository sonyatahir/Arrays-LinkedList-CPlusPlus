// Arrays.cpp : Defines the entry point for the console application.
//


#include "stdafx.h"
#include <string>
#include <iostream>
#include <algorithm>
//#include <stdlib.h>
//#include "stdio.h"
using namespace std;

int factorial(int num) {

	if (num <= 1) {
		return 1;
	}
	else {
		return num * factorial(num - 1);
	}
}

void stringSort() {

	string sentence;
	string words[100];

	getline(std::cin, sentence);

	int w = 0;
	int sentenceLength = sentence.length();
	words[0] = "";
	for (int i = 0; i < sentenceLength; i++) {

		if (int(sentence[i]) >= 64 && int(sentence[i]) <= 90) {
			words[w] += tolower(sentence[i]);
		}
		else if (int(sentence[i]) >= 97 && int(sentence[i]) <= 122) {
			words[w] += sentence[i];
		}
		else if (int(sentence[i]) == 32) {
			w++;
			words[w] = "";
		}
	}

	for (int x = 0; x <= w; x++) {
		std::sort(words[x].begin(), words[x].end());
	}

	/*
	for (int i = 0; i < w; i++) {
	for (int j = w; j > i; j--) {
	if (words[j] < words[j - 1]) {
	string temp = words[j];
	words[j] = words[j - 1];
	words[j - 1] = temp;
	}
	}
	}
	*/
	//int size = sizeof(words) / sizeof(string);

	std::sort(words, words + w + 1);

	cout << words[0];
	for (int s = 1; s <= w; s++) {
		if (words[s] != words[s - 1]) {
			cout << " " << words[s];
		}
	}
}

bool isPermutationOfPalindrome() {

	string line;
	getline(std::cin, line);
	int lineLength = line.length();
	int freq[26] = { 0 };

	for (int i = 0; i < lineLength; i++) {
		if (line[i] != ' ') { // and line[i] is a valid char between a and z
			line[i] = tolower(line[i]);
			freq[int(line[i])-97]++;

		}
	}


	int odd = 0;
	for (int i = 0; i < 26; i++) {
		if (freq[i] % 2 != 0) {
			odd++;
		}
	}

	return odd <= 1;
}

bool OneEditInsert(string first, string second) {
	int x = 0;
	int firstLength = first.length();
	for (int i = 0; i < firstLength; i++) {
		if (first[i] != second[i + x]) {
			if (x == 0) {
				x++;
				i--;
			}
			else {
				return false;
			}

		}
	}
	return true;
}

bool OneEditReplace(string first, string second) {
	int x = 0;
	for (int i = 0; i < first.length(); i++) {
		if (first[i] != second[i]) {
			if (x == 0) {
				x++;
			}
			else {
				return false;
			}
			
		}
	}
	return true;
}

bool OneEditAway() {
	string a, b;
	cin >> a >> b;



	if (a.length() == b.length()) {
		return OneEditReplace(a,b);
	}
	else if (a.length() + 1 == b.length()) {
		return OneEditInsert(a, b);
	}
	else if (b.length() + 1 == a.length()) {
		return OneEditInsert(b, a);
	}
	return false;



}

string CompressedString() {
	string input;
	cin >> input;

	string output = "";
	output += input[0];
	int count = 1;
	for (int i = 1; i < input.length(); i++) {
		if (input[i] == input[i - 1]) {
			count++;
		}
		else {
			output += to_string(count);
			output += input[i];
			count = 1;
		}
	}
	output += to_string(count);

	if (output.length() < input.length()) {
		return output;
	}
	else {
		return input;
	}
	
}


string CompressedString2() {
	char input[100];
	cin.getline(input, 100, '\n');

	int oindex = 0;

	char output[100] = { "" };

	output[oindex] = input[0];

	oindex++;

	int count = 1;
	for (int iindex = 1; iindex < strlen(input); iindex++) {
		if (input[iindex] == input[iindex - 1]) {
			count++;
		}
		else {
			string s = to_string(count);
			s.length();
			for (int a = 0; a < s.length(); a++) {
				output[oindex] = s[a];
				oindex++;
			}
			
			output[oindex] = input[iindex];
			oindex++;
			count = 1;
		}
	}
	string s = to_string(count);
	s.length();
	for (int a = 0; a < s.length(); a++) {
		output[oindex] = s[a];
		oindex++;
	}

	if (strlen(output) < strlen(input)) {
		return output;
	}
	else {
		return input;
	}

}

int main() {
	int a;

	cout << isPermutationOfPalindrome();

	cout << OneEditAway();

	cout << CompressedString2() << endl;

	cout << "Exit:";
	
	cin >> a;
}

